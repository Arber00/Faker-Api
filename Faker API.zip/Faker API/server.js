
const faker = require('faker');
const express = require("express");
const app = express();
const port = 8000;

app.use( express.json() );
app.use( express.urlencoded({ extended: true }) );

const _getNewUser  = () => ({

    _id: faker.datatype.uuid(),
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        phoneNumber: faker.phone.phoneNumber(),
        email: faker.internet.email(),
        password: faker.internet.password()
})

    
const _getNewCompany = () => ({

    _id: faker.datatype.uuid(),
        companyName: faker.company.companyName(),
        address: {
            street: faker.address.streetName(),
            city: faker.address.city(),
            state: faker.address.state(),
            zipCode: faker.address.zipCode(),
            country: faker.address.country(),
        }
})


app.get("/api/users/new", (req, res) => {
        res.json( _getNewUser() );
    });

app.get("/api/companies/new", (req, res) => {
        res.json( _getNewCompany() );
    });

app.get("/api/user/company", (req, res) => {
        res.json( 
        {
            user: _getNewUser(),
            company: _getNewCompany()
        });
    });



app.listen( port, () => console.log(`Listening on port: ${port}`) );